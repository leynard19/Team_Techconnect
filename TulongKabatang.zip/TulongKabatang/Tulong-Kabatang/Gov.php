<?php
require "header.php";
?>
<style>
  img {
  width: 200px;
  height: 200px;
  display: block;
  margin-left: auto;
  margin-right: auto;
}

</style>

<section id="gov">
 <div class="container">
   <h3 class="text-center"><br><br>Government Agencies</h3>
   <div class="row">
<!--carousel-->
     <div><br><br>
      	<img src="img/Gov1.png" style="margin-left: 12.4cm">
     </div>

<!--end of carousel-->
     <div>
    	<div class="arranging"><hr>
	<h4 class="text-center">Department of Social Welfare and Development</h4>
	<p><br>The Philippines' Department of Social Welfare and Development (Filipino: Kagawaran ng Kagalingan at Pagpapaunlad Panlipunan, abbreviated as DSWD) is the executive department of the Philippine Government responsible for the protection of the social welfare of rights of Filipinos and to promote the social development.<br><br></p>
  <h5 style="text-align: center;">Programs and Service</h5>
  <p></p>
	</div>
     </div>
    </div><br>
  </div>
</section>