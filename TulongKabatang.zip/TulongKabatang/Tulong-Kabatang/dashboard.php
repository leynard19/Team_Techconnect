<style>
  
img {
  width: 100px;
  height: 200px;
  display: block;
  margin-left: auto;
  margin-right: auto;
}
span {
  text-align: center;


}
</style>


        <div class="row">
          <div class="col-12 col-sm-6 col-md-4">
            <div class="info-box">
              <div class="info-box-content" >
                <img src="img/municon.png">
                <span class="info-box-text">Number of Municipalties</span>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-md-4">
            <div class="info-box mb-3">
              <div class="info-box-content">
                <img src="img/cal3.jpg" style="width: 300px">
                <span class="info-box-text">Disaster Watch</span>
              </div>
            </div>
          </div>
         
          <div class="clearfix hidden-md-up"></div>
          <div class="col-12 col-sm-6 col-md-4">
            <div class="info-box mb-3">
              <div class="info-box-content">
                <img src="img/relief.jpg" style="width: 300px">
                <span class="info-box-text">Relief Goods Status</span>
              </div>
            </div>
          </div>
        </div>