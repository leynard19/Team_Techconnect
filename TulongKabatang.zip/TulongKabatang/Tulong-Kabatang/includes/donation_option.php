 <div class="container" style="background-image: url('img/donate.jpg'); background-repeat: no-repeat; background-size: 100% 100%" >
    <h2>Donation</h2>
  <!-- Trigger the modal with a button -->
    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Click Here  </button>
  <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">
                  <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Choose Donation Option</h4>
          </div>
          <div class="modal-body">
            <section id=option>
              <div class="container">
                <div class="row">
                  <div class="col-sm"> 
                    <img class="d-block w-100 h-50" src="img/fdonate.jpg" alt="First slide">
                    <h5 style="text-align: center;"> Finance Donation</h5>
                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#Fdonation" style="margin-left: 1cm">Click Here  </button>
                  </div>
                  <div class="col-sm">
                    <img class="d-block w-100 h-50" src="img/sdonate.jpg" alt="First slide">
                    <h5 style="text-align: center"> Supplies Donation</h5>
                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#sdonation" style="margin-left: 1cm">Click Here  </button>
                  </div>
                </div>
              </div> 
            </section>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div> 
      </div>
    </div>
    <?php
    require "includes/fdonation.php";
    require "includes/sdonation.php";
    ?>
    
  </div>