 <div class="container">
  <!-- Trigger the modal with a button -->
  <!-- Modal -->
    <div class="modal fade" id="sdonation" role="dialog">
      <div class="modal-dialog">
                  <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title"> Register</h4>
          </div>
          <div class="modal-body">
            <div class="container">
              <h2>Supplies Donation</h2>
              <form action="/action_page.php">
                <div class="form-group">
                  <label for="name">Full Name:</label>
                  <input type="name" class="form-control" id="fullname" placeholder="Enter Full-Name" name="name">
                </div>
                <div class="form-group">
                  <label for="email">Email:</label>
                  <input type="email" class="form-control" id="email" placeholder="Enter E-mail" name="email">
                </div>
                <div class="form-group">
                  <label for="contact">Contact Number:</label>
                  <input type="contact" class="form-control" id="contact" placeholder="Enter Contact Number" name="contact">
                </div>
                <div class="form-group">
                  <label>Foundation Partners</label>
                    <select class="form-control" id="cat" name="cat">
                      <option value="">Select Foundation Partne</option>
                      <?php 
                      require 'dbh.inc.php';
                        //category table
                        $fpartners = "SELECT * FROM foundationpatners";
                        $fpartners_res = mysqli_query($conn,$fpartners);
                        while($row = mysqli_fetch_assoc($fpartners_res) ){
                            $fid = $row['fpartnersID'];
                            $fname = $row['fpartnersName'];
                            Print "<option value='".$fid."' >".$fname."</option>";
                        }
                      ?>
                    </select>
                </div>
                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#sdonationitem">Proceed Here  </button>
              </form>
          </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div> 
      </div>
    </div>
    <?php
    require'sdonationitems.php'  
    ?>
  </div>