<div class="modal fade" id="bankdonation" role="dialog">
      <div class="modal-dialog">
                  <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Donation Form</h4>
          </div>
          <div class="modal-body">
             <div class="container">

      <div class="container">
        <div>
          <div>
            <div>
              <div class="panel-heading">
                <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <h5 class="text-muted"> Bank Number</h5>
                  </div>

                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <input type="text" class="form-control" placeholder="0000" required="" />
                  </div>

                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <input type="text" class="form-control" placeholder="0000" required="" />
                  </div>

                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <input type="text" class="form-control" placeholder="0000" required="" />
                  </div>

                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <input type="text" class="form-control" placeholder="0000" required="" />
                  </div>
                </div>
                <br>
                <div class="row ">
                  <div class="col-md-5 col-sm-5 ">
                    <span class="help-block text-muted small-font"> Expiry Month</span>
                    <input type="text" class="form-control" placeholder="MM" required="" />
                  </div>

                  <div class="col-md-5 col-sm-5 ">
                    <span class="help-block text-muted small-font">  Expiry Year</span>
                    <input type="text" class="form-control" placeholder="YY" required="" />
                  </div>
                  
                  <div class="col-md-5 col-sm-5 ">
                    <span class="help-block text-muted small-font">  CCV</span>
                    <input type="text" class="form-control" placeholder="CCV" required="" />
                  </div>
                </div>
                <br>
                <div class="row ">
                  <div class="col-md-12 pad-adjust">
                    <input type="text" class="form-control" placeholder="Name On The Card" required="" />
                  </div>
                </div>
                <div class="row ">
                  <div class="col-md-12 pad-adjust">
                    <input type="text" class="form-control" placeholder="Amount" required="" />
                  </div>
                </div>
                <br>
                <div class="row">
                </div>
                <div class="row ">
                  <div class="col-md-6 col-sm-6 col-xs-6 pad-adjust">
                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-dismiss="modal" >Cancel </button>   
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-6 pad-adjust">

                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#thankyou"> Donate </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div> 
      </div>
    </div>

     <div class="modal fade" id="thankyou" role="dialog">
      <div class="modal-dialog">
                  <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Thank you so much!</h4>
          </div>         
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div> 
      </div>
    </div>
