 <div class="container" style="background-image: url('img/volunteer.jpg'); background-repeat: no-repeat;background-size: 100% 100%">
    <h2>Volunteer</h2>
  <!-- Trigger the modal with a button -->
    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#volunteer">Click Here  </button>
  <!-- Modal -->
    <div class="modal fade" id="volunteer" role="dialog">
          <div class="modal-dialog">
                      <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title"> Register</h4>
              </div>
              <div class="modal-body">
                <div class="container">
                  <h2>Volunter Form</h2>
                  <form action="/action_page.php">
                    <div class="form-group">
                      <label for="name">Full Name:</label>
                      <input type="name" class="form-control" id="fullname" placeholder="Enter Full-Name" name="name">
                    </div>
                    <div class="form-group">
                      <label for="email">Email:</label>
                      <input type="email" class="form-control" id="email" placeholder="Enter E-mail" name="email">
                    </div>
                    <div class="form-group">
                      <label for="contact">Contact Number:</label>
                      <input type="contact" class="form-control" id="contact" placeholder="Enter Contact Number" name="contact">
                    </div>
                    <div class="form-group">
                      <label>Bank Partners</label>
                        <select class="form-control" id="cat" name="cat">
                          <option value="">Select Bank Partne</option>
                          <?php 
                          require 'dbh.inc.php';
                            //category table
                            $bankpartners = "SELECT * FROM bankpartners";
                            $bankpartners_res = mysqli_query($conn,$bankpartners);
                            while($row = mysqli_fetch_assoc($bankpartners_res) ){
                                $id = $row['bankID'];
                                $bankname = $row['bankname'];
                                Print "<option value='".$id."' >".$bankname."</option>";
                            }
                          ?>
                        </select>
                    </div>
                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#bankdonation">Proceed Here  </button>
                  </form>
              </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div> 
          </div>
        </div>
  </div>