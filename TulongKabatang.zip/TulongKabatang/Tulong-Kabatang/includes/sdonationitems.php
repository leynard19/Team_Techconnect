 <div class="container">
  <!-- Trigger the modal with a button -->
  <!-- Modal -->
    <div class="modal fade" id="sdonationitem" role="dialog">
      <div class="modal-dialog">
                  <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-body">
            <div class="container">
              <h2>Supplies Donation</h2>
              <form action="/action_page.php">
                <div class="form-group">
                  <label for="itemname">Item Name:</label>
                  <input type="itemname" class="form-control" id="itemname" placeholder="Enter Item Name" name="itemname">
                </div>
                <div class="form-group">
                  <label for="desc">Description:</label>
                  <input type="desc" class="form-control" id="desc" placeholder="Enter Description" name="desc">
                </div>
                <div class="form-group">
                  <label for="noItem">Number of Items:</label>
                  <input type="noItem" class="form-control" id="noItem" placeholder="Enter Number of Items" name="noItem">
                </div>
                <div class="form-group">
                  <label> Select Item Category</label>
                    <select class="form-control" id="cat" name="cat">
                      <option value="">Select Item Category</option>
                      <?php 
                      require 'dbh.inc.php';
                        //category table
                        $cat = "SELECT * FROM foundationpatners";
                        $cat_res = mysqli_query($conn,$cat);
                        while($row = mysqli_fetch_assoc($cat_res) ){
                            $cid = $row['CatID'];
                            $cname = $row['catname'];
                            Print "<option value='".$cid."' >".$cname."</option>";
                        }
                      ?>
                    </select>
                </div>
                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#bankdonation">Proceed Here  </button>
              </form>
          </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div> 
      </div>
    </div>
    <?php
    require'bankdonation.php'  
    ?>
  </div>