<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto ">
      <!-- Notifications Request -->
      <li class="nav-item">
        <a class="nav-link" href="includes/logout.inc.php" role="button">
          <i class="fas fa-power-off"></i> Logout
        </a>
      </li>
    </ul>
</nav>