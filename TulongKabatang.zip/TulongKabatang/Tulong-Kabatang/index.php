<?php
require "header.php";
?>

<header class="header" style="background-image: url('img/background.jpg')">
    <div class="row">
        <div class="col-md-12 text-center">
            <a class="logo"><img src="img/Logo.png" alt="logo" style=" width: auto;"></a>
        </div>
    </div>
</header>

<body>
<section id=aboutus>
    <div class="container">
    <div class="row">
    <div class="col-sm ">
        <div class="arranging"><br><hr>
            <h4 class="text-center">Mission</h4>
            <p>The Tulong Ka-Batang will ensure preparedness through coordination with everyone that the province is prepared to respond to and recover from all natural and man-made disaster</p>
            <p>1. It will provide support to people that suffer in disaster.<br>
                2. It  will respond easily, faster and efficient.<br>
                3. It will recommend a safest location.<br>
                4. It will recommend supplies based on the needs of individual and families.</p>
        </div>
    </div>
    <div class="col-sm ">
        <div class="arranging"><br><hr>
            <h4 class="text-center">Vision</h4>
            <p>The system is for government agencies , volunteer and private organizations with effective plans that is necessary for efficient disaster response, safer and more resilient communities.</p> 
        </div>
    </div>
    </div>

</div>
</section>


<br><br>
<?php
require "Government.php";
require "Dos.php";
require "Evacuation.php";
?>
<br><br>

<!-- main page map section-->
<section class="map" id="contactus">
    <div class="container">
        <div class="row" >
            <div class="col-sm">
              <?php
                require "includes/donation_option.php"
              ?>
            </div>
            <div class="col-sm">
              <?php
                require "includes/volunteer.php"
              ?>
            </div>

            
    </div>


    </div>
    
    <div class="container">
    <h3 class="text-center"><br><br>Contact Us!</h3><br>
        <iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d495681.89370590326!2d120.56148855407339!3d13.927925427333806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e0!4m5!1s0x33bd1b1d4c1cd013%3A0xe4592a820e411177!2sBatangas%20City%2C%20Batangas%2C%20Philippines!3m2!1d13.7564651!2d121.05830759999999!4m5!1s0x33bd96a41ab0b4f7%3A0xdaa68526de415f40!2sBatStateU%20ARASOF%20Nasugbu%20Library%2C%20Nasugbu%2C%20Batangas%2C%20Philippines!3m2!1d14.067332299999999!2d120.62648759999999!5e0!3m2!1sen!2sgr!4v1626858459272!5m2!1sen!2sgr" style= "width:100%;  height:250px; border:0;" allowfullscreen></iframe>

            <div class="col" >
            
            <p class="text-right">Tulong Ka-Batang<br>email: tulongka-batang@gmail.com<br>phone: +63 952 456 7890</p>
            </div>

	</div>
    
</section>
<!--end of main page map section-->

</body>
<?php
require "footer.php";
?>