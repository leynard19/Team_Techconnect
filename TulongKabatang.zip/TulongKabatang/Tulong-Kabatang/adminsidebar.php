<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="admin.php" class="brand-link">
      <br>
      <center><span class="brand-text font-weight-light"> Tulong Ka-Batang | Admin</span></center>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <br><br>
          <li class="nav-item">
            <a href="admin.php" class="nav-link">
              
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="UserManagement.php" class="nav-link">
              <p>
                User Management
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="Donation.php" class="nav-link">        
              <p>
                Donation
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="Volunteers.php" class="nav-link">  
              <p>
                Volunteers
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="Municipalities.php" class="nav-link">
              <p>
                Municipalities
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="Reports.php" class="nav-link">
              <p>
                Reports
              </p>
            </a>
          </li>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>