<!--footer-->
<footer class="footer" id="footer">
 <div class="container"><br>
  <div class="row">
    <div class="col-sm-12 text-center">
      <div class="copyright">
        <p class="white"> copyright &copy; <b>Tulong Ka-Batang</b></p>
        
      </div>
    </div>
  </div>
 </div>
</footer>
<!--end of footer-->
</body>
<!---end of body-->
</html>