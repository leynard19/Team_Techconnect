	$(document).ready(function() {
	function load_unseen_notification(view = '') {
		$.ajax({
			url: '../admin/php_function/fetch_request.php',
			method: "POST",
			data: { view:view },
			dataType: "json",
			success:function(data) {
				$('.seen').html(data.notification);
				if (data.unseen_notification > 0) {
					$('.count').html(data.unseen_notification);
				}
			}
		});
	}
	load_unseen_notification();
	$(document).on('click', '.data-toggle', function(){
		$('.count').html('');
  load_unseen_notification('yes');
 });
	setInterval(function(){ 
	  load_unseen_notification();;
	 }, 1000);
})