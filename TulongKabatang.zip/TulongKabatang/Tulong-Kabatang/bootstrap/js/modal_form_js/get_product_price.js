$(document).ready(function() {
	$("#pcat").change(function() {
		var procat = $(this).val();
		$.ajax({
			url: '../customer/get_product.php',
			type: 'post',
			data: {procat:procat},
			dataType: 'json',
			success: function(responses) {
				var lens = responses.length;
				$("#namepro").empty();
				for ( var i = 0; i < lens; i++ ) {
					var id  = responses[i]['product_id'];
					var prodname  = responses[i]['product_name'];
					$("#namepro").append("<option value='"+id+"'>"+prodname+"</option>");
				}
			}
		})
	})
	$("#namepro").change(function() {
		var price = $(this).val();
		$.ajax({
			url: '../customer/get_product_price.php',
			type: 'post',
			data: { price:price },
			dataType: 'json',
			success: function(response) {
				var len = response.length;
				for (var i = 0; i < len; i++) {
					var p_price = response[i]['product_price'];
					var pquan = response[i]['product_quantity'];
					//var size = response[i]['product_size'];
					$("#price").val(p_price);
					$("#pquan").val(pquan);
					//$("#sizes").val(size);
					$("#csize").show();
				}
			}
		})
	});

	$("#quantity").keyup(function() {
		var quantity = $("#quantity").val();
		var price = $("#price").val();
		var p_quantity =$("#pquan").val();
		console.log(p_quantity);
		var ans;
		var ans2;
		ans = quantity * price;
		$("#total").val(ans);
		ans2 = p_quantity - quantity;
		
		if (parseInt(quantity) < parseInt(p_quantity)) {
			$("#create_order").attr('disabled',false);
		}else if(parseInt(quantity) === parseInt(p_quantity)){
			alert('Your Request Quantity is equal to our available Stock !');
			$("#create_order").attr('disabled',false);
		}else{
			alert('Your Request Quantity is greater than our available Stock !');
			$("#create_order").attr('disabled',true);
		}
	})
})