$(document).ready(function(){
	$("#login").click(function(){
		//toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
		var username = $("#username").val();
		var password = $("#password").val();
		if (username !="" & password !="") {
			$.ajax({
				url:'login.php',
				method: 'post',
				data:{ username:username, password:password },
				dataType: 'json',
				beforeSend: function() {
					$("#login").attr("disabled", true).html("Logging in <span class='fa fa-spinner fa-1x fa-spin'></span>");
				},
				success: function(response) {
					if (response.role === 'Admin') {
						window.location = 'admin/index.php';
					}else if (response.role === 'customer') {
						window.location = 'customer/';
					}else{
						toastr.error(response.msg);
						toastr.error(response.not);
						$("#login").attr("disabled", false).html('Login');
					}
				}
			})
		}else{
			toastr.warning('Username and Password are REQUIRED !')
		}
	})
})

