$(document).ready(function() {
	//display modal add_product
	$("#product").click(function(){
		$("#product_modal").modal('show');
	});
});