$(document).ready(function(){
	$("#category").click(function() {
		$("#modal-default").modal('show');
		$("#cat_form")[0].reset();
		$("#save_cat").show();
		$("#edit_cat").hide();
	})
	$("#save_cat").click(function(){
		var cat = $("#cat").val();
		var id = $("#id").val();

		if (cat != '') {
			$.ajax({
				url: '../admin/php_function/add_category_function.php',
				type: 'post',
				data: { cat:cat, id:id },
				beforeSend: function(){
					$("#save_cat").attr("disabled", true).html("Processing ... <span class='fa fa-spinner fa-1x fa-spin'></span>");
				},
				success: function(data) {
					var data = JSON.parse(data);
					if (data.statusCode == 200) {
						$("#modal-default").modal('hide');
						$("#suc").show();
						alert('Successfully Added !');
						$("#save_cat").attr("disabled", false).html("Submit");
						show_cat();
					}else if(data.res == "err") {
						alert('Error');
					}
				}
			});
		}else {
			alert('Required !');
			return false;
		}
	});

	$("#edit_cat").click(function(){
		var cat = $("#cat").val();
		var id = $("#id").val();
		var catid = $("#idcat").val();
		$.ajax({
			url: '../admin/php_function/update_category.php',
			type: 'post',
			data: { cat:cat, id:id, catid:catid },
			beforeSend: function(){
				$("#edit_cat").attr("disabled", true).html("Updating... <span class='fa fa-spinner fa-1x fa-spin'></span>");
			},
			success: function(data) {
				var data = JSON.parse(data);
				if (data.statusCode == 200) {
					$("#modal-default").modal('hide');
					$("#suc").show();
					$("#edit_cat").attr("disabled", false).html("Save Changes");
					show_cat();
				}else if(data.res == "err") {
					alert('Error');
				}
			}
		});
	});


	show_cat();
	function show_cat() {
		$.ajax({
				url: '../admin/php_function/show_category.php',
				method:"POST",
				dataType: 'json',
				success:function(data)
				{
					var html = '';
					var i;
					for ( i = 0; i<data.length; i++) {
						 html += 
						 '<tr>'+
							 '<td>'+data[i].category_name+'</td>'+
							 '<td>'+data[i].first_name+'</td>'+
							 '<td>'+data[i].date+'</td>'+
							 '<td>'+'<button class="btn btn-info btn-sm item_edit" data-title="'+data[i].category_name+'" data-cat_id = "'+data[i].cat_id+'"> Edit Details</button>'+'</td>'+
						 '</tr>';
					}
					$('#tbody-cat').html(html);
					$("#example1").DataTable();
					$('.item_edit').click(function() {
						$catname = $(this).data('title');
						$catid = $(this).data('cat_id');
						$("#save_cat").hide();
						$("#edit_cat").show();
						$("#modal-default").modal('show');
						$("#cat").val($catname);
						$("#idcat").val($catid);
					});
					$("#edit_cat").click(function() {

					})
				}
			});
	}

})