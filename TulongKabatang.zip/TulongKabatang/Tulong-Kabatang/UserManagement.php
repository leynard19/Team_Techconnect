<?php 
require 'admin.php';
?>